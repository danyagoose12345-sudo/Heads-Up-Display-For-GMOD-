-- Отключаем стандартный HUD Garry's Mod
local hide = {
    ["CHudHealth"] = true,
    ["CHudBattery"] = true,
    ["CHudAmmo"] = true,
    ["CHudSecondaryAmmo"] = true
}

hook.Add("HUDShouldDraw", "HideDefaultHUD", function(name)
    if hide[name] then return false end
end)

-- Создаем шрифты (Шрифт Arial отлично подходит для стиля GTA)
surface.CreateFont("GTA_HUD_Large", {
    font = "Arial",
    size = 36,
    weight = 800,
    antialias = true
})

surface.CreateFont("GTA_HUD_Medium", {
    font = "Arial",
    size = 26,
    weight = 700,
    antialias = true
})

surface.CreateFont("GTA_HUD_Small", {
    font = "Arial",
    size = 14,
    weight = 700,
    antialias = true
})

-- Локальная функция плавной смены цвета (замена отсутствующей LerpColor)
local function BlendColor(t, c1, c2)
    return Color(
        Lerp(t, c1.r, c2.r),
        Lerp(t, c1.g, c2.g),
        Lerp(t, c1.b, c2.b),
        Lerp(t, c1.a, c2.a)
    )
end

-- Таблица связи классов оружия с твоими PNG-иконками
local weaponIcons = {
    ["weapon_crowbar"]    = Material("vgui/crowbar.png", "nocull smooth"),
    ["weapon_pistol"]     = Material("vgui/9mm.png", "nocull smooth"),
    ["weapon_357"]        = Material("vgui/357.png", "nocull smooth"),
    ["weapon_bugbait"]    = Material("vgui/bugbait.png", "nocull smooth"),
    ["weapon_crossbow"]   = Material("vgui/crossbow.png", "nocull smooth"),
    ["weapon_physcannon"] = Material("vgui/gravygun.png", "nocull smooth"),
    ["weapon_grenade"]    = Material("vgui/grenade.png", "nocull smooth"),
    ["weapon_ar2"]        = Material("vgui/irifle.png", "nocull smooth"),
    ["weapon_physgun"]    = Material("vgui/physgun.png", "nocull smooth"),
    ["weapon_rpg"]        = Material("vgui/rpg.png", "nocull smooth"),
    ["weapon_shotgun"]    = Material("vgui/shotgun.png", "nocull smooth"),
    ["weapon_slam"]       = Material("vgui/slam.png", "nocull smooth"),
    ["weapon_smg1"]       = Material("vgui/smg.png", "nocull smooth"),
    ["weapon_stunstick"]  = Material("vgui/sunstick.png", "nocull smooth")
}

hook.Add("HUDPaint", "DrawGTAHUD_Complete", function()
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return end

    -- Размеры и базовая позиция основного блока HUD (в правом верхнем углу)
    local hudW, hudH = 360, 115
    local hudX, hudY = ScrW() - hudW - 30, 30

    -- Получаем данные игрока
    local hp = ply:Health()
    local armor = ply:Armor()
    local weapon = ply:GetActiveWeapon()

    -- Цвета
    local bgColor = Color(0, 0, 0, 160)
    local textAmmoColor = Color(225, 170, 45) -- Фирменный оранжевый для патронов
    local moneyColor = Color(50, 140, 60)     -- Зеленый для денег GTA
    local white = Color(255, 255, 255)

    -- Рассчитываем мигание здоровья, если оно ниже 25 единиц
    local hpColor = Color(180, 25, 25)
    if hp <= 25 then
        local blink = math.abs(math.sin(CurTime() * 7)) -- Быстрое мигание
        hpColor = BlendColor(blink, Color(60, 10, 10), Color(240, 30, 30))
    end
    local armorColor = Color(25, 100, 150)

    -- ==========================================
    -- 1. ЧАСЫ И ДЕНЬГИ (Рисуются НАД основным HUD)
    -- ==========================================
    
    -- Время (формат ЧЧ:ММ)
    local currentTime = os.date("%H:%M")
    draw.SimpleText(currentTime, "GTA_HUD_Medium", ScrW() - 32, hudY, white, TEXT_ALIGN_RIGHT)
    
    -- Сдвигаем HUD вниз, чтобы освободить место под часы
    hudY = hudY + 35

    -- Деньги (Интеграция с DarkRP / Sandbox)
    local moneyText = ""
    if ply.getDarkRPAmount then
        moneyText = "$" .. string.Comma(ply:getDarkRPAmount())
    else
        -- Заглушка для Sandbox (выводим количество фрагов или красивое число)
        moneyText = "$" .. string.Comma(ply:Frags() * 1000) 
    end
    draw.SimpleText(moneyText, "GTA_HUD_Large", ScrW() - 32, hudY, moneyColor, TEXT_ALIGN_RIGHT)
    
    -- Сдвигаем основной HUD еще ниже под блок денег
    hudY = hudY + 45

    -- ==========================================
    -- 2. ОСНОВНОЙ БЛОК (Иконка оружия + полоски)
    -- ==========================================
    
    -- Задний фон основного блока
    draw.RoundedBox(0, hudX, hudY, hudW, hudH, bgColor)

    -- --- ДОБАВЛЯЕМ ОБВОДКУ ДЛЯ ИКОНКИ ОРУЖИЯ ---
    local iconX, iconY = hudX + 15, hudY + 18
    local iconW, iconH = 90, 80
    local strokeThickness = 2 -- Толщина обводки в пикселях
    local strokeColor = Color(0, 0, 0, 255) -- Черный цвет для рамки

    -- Рисуем черную рамку-обводку вокруг будущей иконки
    surface.SetDrawColor(strokeColor)
    for i = 1, strokeThickness do
        surface.DrawOutlinedRect(iconX - i, iconY - i, iconW + (i * 2), iconH + (i * 2))
    end
    -- -------------------------------------------

    -- Отрисовка Иконки Оружия внутрь рамки
    if IsValid(weapon) then
        local wepClass = weapon:GetClass()
        local customIcon = weaponIcons[wepClass]

        if customIcon and not customIcon:IsError() then
            surface.SetMaterial(customIcon)
            surface.SetDrawColor(255, 255, 255, 255)
            surface.DrawTexturedRect(iconX, iconY, iconW, iconH)
        else
            draw.SimpleText("🔫", "GTA_HUD_Large", iconX + (iconW / 2), iconY + (iconH / 2), white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        -- Отрисовка Патронов (Справа вверху внутри блока)
        local clip1 = weapon:Clip1()
        local reserve = ply:GetAmmoCount(weapon:GetPrimaryAmmoType())
        local ammoText = ""

        if clip1 >= 0 then
            ammoText = clip1 .. "   " .. reserve
        elseif reserve > 0 then
            ammoText = tostring(reserve)
        end

        if ammoText ~= "" then
            draw.SimpleText(ammoText, "GTA_HUD_Large", hudX + hudW - 20, hudY + 15, textAmmoColor, TEXT_ALIGN_RIGHT)
        end
    end

    -- --- ВОЗВРАЩАЕМ ПОЛОСКИ ЗДОРОВЬЯ И БРОНИ НА МЕСТО ---
    local barW = 210
    local barH = 12
    local barsX = hudX + hudW - barW - 20
    local hpY = hudY + 65
    local armorY = hudY + 85

    -- Полоска Жизней
    local hpProgress = math.Clamp(hp, 0, 100) / 100 * barW
    draw.RoundedBox(0, barsX, hpY, barW, barH, Color(40, 10, 10, 220)) -- Черный фон под HP
    if hpProgress > 0 then
        draw.RoundedBox(0, barsX, hpY, hpProgress, barH, hpColor)      -- Сама полоска
    end
    draw.SimpleText("HP", "GTA_HUD_Small", barsX - 30, hpY - 1, white)

    -- Полоска Брони
    local armorProgress = math.Clamp(armor, 0, 100) / 100 * barW
    draw.RoundedBox(0, barsX, armorY, barW, barH, Color(10, 30, 40, 220)) -- Черный фон под броню
    if armorProgress > 0 then
        draw.RoundedBox(0, barsX, armorY, armorProgress, barH, armorColor)  -- Сама полоска
    end
    draw.SimpleText("ARM", "GTA_HUD_Small", barsX - 35, armorY - 1, white)

end)
